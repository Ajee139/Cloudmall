package com.example.cloudmall_africa_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
