import "package:flutter/material.dart";

class CloudMallHomePage extends StatelessWidget {
  const CloudMallHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Image.asset(
        "images/android cloud mall image 12.png",
        height: 300,
        width: 200,
        fit: BoxFit.contain,
      ),
    );
  }
}
